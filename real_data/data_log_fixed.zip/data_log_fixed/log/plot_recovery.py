#!/usr/bin/env python3
"""Plot a recovery log CSV: projected gravity + 12 joint torques + 12 joint positions.

Usage:
    python plot_recovery.py [/abs/or/rel/path/to/recovery_xxxx.csv]
Accepts an absolute or relative CSV path. With no argument, falls back to DEFAULT_CSV.
The output PNG is written next to the CSV.
"""
import os
import sys
import numpy as np
import matplotlib.pyplot as plt

DEFAULT_CSV = "/home/wang/Lite3_controller/Lite3_rl_deploy/log/N=1/HIP_FL/stuck/recovery_20260607_225158.csv"
csv = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_CSV

data = np.genfromtxt(csv, delimiter=",", names=True)
t = data["t"] - data["t"][0]   # time relative to start

has_q = "q0" in data.dtype.names
nrows = 3 if has_q else 2
fig, axes = plt.subplots(nrows, 1, figsize=(12, 4 * nrows), sharex=True)
ax_pg, ax_tau = axes[0], axes[1]

# --- Projected gravity ---
for axis, color in zip("xyz", ("C0", "C1", "C2")):
    ax_pg.plot(t, data[f"pg_{axis}"], color, label=f"pg_{axis}")
ax_pg.set_ylabel("projected gravity")
ax_pg.set_title(f"Recovery log: {os.path.basename(csv)}")
ax_pg.legend(loc="upper right", ncol=3)
ax_pg.grid(True, alpha=0.3)

# --- Joint torques ---
for i in range(12):
    ax_tau.plot(t, data[f"tau{i}"], label=f"tau{i}", linewidth=0.8)
ax_tau.set_ylabel("joint torque")
ax_tau.legend(loc="upper right", ncol=6, fontsize=8)
ax_tau.grid(True, alpha=0.3)

# --- Joint positions ---
if has_q:
    ax_q = axes[2]
    for i in range(12):
        ax_q.plot(t, data[f"q{i}"], label=f"q{i}", linewidth=0.8)
    ax_q.set_ylabel("joint position [rad]")
    ax_q.legend(loc="upper right", ncol=6, fontsize=8)
    ax_q.grid(True, alpha=0.3)

axes[-1].set_xlabel("time [s]")

fig.tight_layout()
out = os.path.splitext(csv)[0] + ".png"
fig.savefig(out, dpi=120)
print(f"saved {out}")
plt.show()
