# Recovery Log Format (`recovery_*.csv`)

Written by `PolicyLogger` (`utils/policy_logger.hpp`) from the recovery state
(`state_machine/rl_recovery_state_onnx.hpp:129`). One row per main-loop iteration.

## Columns

`t, pg_x, pg_y, pg_z, tau0 … tau11`

- **`t`** — interface timestamp [s] (`GetInterfaceTimeStamp()`).
- **`pg_x/y/z`** — projected gravity in the base frame; upright ⇒ `pg_z ≈ -1`, `pg_x,pg_y ≈ 0`.
- **`tau0…tau11`** — joint torques [N·m], logged straight from `GetJointTorque()`.

## Sample rate

- **Nominal ~1 kHz** (1 ms per sample) — median Δt = 1.000 ms, set by the sim's
  1 kHz step / timestamp resolution.
- **Actual mean ≈ 981 Hz** with jitter: occasional 2 ms gaps and a few duplicate
  timestamps (Δt = 0).
- Rule of thumb: **x-axis seconds × ~1000 ≈ sample index**. (Not the full 2 kHz
  main-loop rate — logging is at the 1 ms timestamp resolution.)

## Joint order of `tau0…tau11`

Logged **directly, with NO Isaac reordering** — robot native **MuJoCo leg-major**
order (legs FL, FR, HL, HR; each `[HipX, HipY, Knee]`):

| col  | joint   | col   | joint   |
| ---- | ------- | ----- | ------- |
| tau0 | FL_HipX | tau6  | HL_HipX |
| tau1 | FL_HipY | tau7  | HL_HipY |
| tau2 | FL_Knee | tau8  | HL_Knee |
| tau3 | FR_HipX | tau9  | HR_HipX |
| tau4 | FR_HipY | tau10 | HR_HipY |
| tau5 | FR_Knee | tau11 | HR_Knee |

> ⚠️ This is the **opposite** of the policy's internal obs/action vectors, which use
> Isaac **type-major** order (all HipX, all HipY, all Knee).
> Mapping: `isaac2robot = [0,4,8, 1,5,9, 2,6,10, 3,7,11]`,
> `robot2isaac = [0,3,6,9, 1,4,7,10, 2,5,8,11]`.

## Plotting

```bash
conda activate lite3_rec        # or: ~/miniconda3/bin/conda run -n lite3_rec ...
python log/plot_recovery.py [recovery_xxxx.csv]   # defaults to recovery_20260607_035432.csv
```

Outputs a `.png` next to the CSV: projected gravity (top) + 12 joint torques (bottom).
